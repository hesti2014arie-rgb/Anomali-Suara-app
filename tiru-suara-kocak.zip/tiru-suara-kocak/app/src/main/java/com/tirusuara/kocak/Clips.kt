package com.tirusuara.kocak

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Satu "soal" di game: foto karakter + suara yang harus ditiru.
 * - synth != null  -> suara dibuat otomatis (bawaan app, aman dari hak cipta)
 * - audio != null  -> URL (http...) atau nama file di assets/clips/
 */
data class Clip(
    val id: String,
    val title: String,
    val character: String,
    val emoji: String,
    val imageUrl: String?,
    val audio: String?,
    val synth: String?
)

object ClipRepo {
    private val pcmCache = HashMap<String, ShortArray>()
    private val imgCache = HashMap<String, ImageBitmap>()

    fun load(ctx: Context): List<Clip> {
        val list = ArrayList<Clip>()
        list += Clip("synth_naik", "Lift ke Langit", "Alien Naik Lift", "🛸", null, null, "naik")
        list += Clip("synth_ayam", "Petok Petok Galau", "Ayam Kehabisan Pulsa", "🐔", null, null, "ayam")
        list += Clip("synth_roller", "Rollercoaster Suara", "Tuyul Naik Wahana", "🎢", null, null, "roller")
        list += Clip("synth_tangga", "Tangga Nada Pelit", "Robot Hemat Baterai", "🤖", null, null, "tangga")
        try {
            val txt = ctx.assets.open("clips.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(txt)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id")
                val audio = o.optString("audio")
                if (id.isBlank() || audio.isBlank()) continue
                list += Clip(
                    id = "c_$id",
                    title = o.optString("title", id),
                    character = o.optString("character", ""),
                    emoji = o.optString("emoji", "🎭"),
                    imageUrl = o.optString("image").ifBlank { null },
                    audio = audio,
                    synth = null
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    suspend fun pcm(ctx: Context, clip: Clip): ShortArray = withContext(Dispatchers.IO) {
        synchronized(pcmCache) { pcmCache[clip.id] }?.let { return@withContext it }
        val data: ShortArray = if (clip.synth != null) {
            Synth.render(clip.synth)
        } else {
            val a = clip.audio ?: throw IllegalStateException("Klip tanpa audio")
            val f = File(ctx.cacheDir, "clip_${clip.id.hashCode()}.bin")
            if (!f.exists() || f.length() == 0L) {
                if (a.startsWith("http")) {
                    f.writeBytes(Http.download(a))
                } else {
                    ctx.assets.open("clips/$a").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                }
            }
            AudioDecoder.decodeFile(f.absolutePath, MAX_SEC)
        }
        synchronized(pcmCache) { pcmCache[clip.id] = data }
        data
    }

    suspend fun image(clip: Clip): ImageBitmap? = withContext(Dispatchers.IO) {
        val u = clip.imageUrl ?: return@withContext null
        synchronized(imgCache) { imgCache[u] }?.let { return@withContext it }
        try {
            val bytes = Http.download(u, 6_000_000)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.asImageBitmap()
            if (bmp != null) synchronized(imgCache) { imgCache[u] = bmp }
            bmp
        } catch (e: Exception) {
            null
        }
    }
}

/** Pembuat suara bawaan (nada naik-turun mirip suara) supaya game langsung bisa dimainkan. */
object Synth {
    private class Seg(val dur: Float, val f0: Float, val f1: Float, val amp: Float = 0.7f)

    fun render(kind: String): ShortArray {
        val segs: List<Seg> = when (kind) {
            "naik" -> listOf(Seg(2.4f, 140f, 330f))
            "ayam" -> listOf(
                Seg(0.25f, 380f, 300f), Seg(0.12f, 0f, 0f, 0f),
                Seg(0.25f, 380f, 300f), Seg(0.12f, 0f, 0f, 0f),
                Seg(0.25f, 380f, 300f), Seg(0.20f, 0f, 0f, 0f),
                Seg(0.80f, 300f, 170f)
            )
            "roller" -> listOf(
                Seg(0.9f, 150f, 320f), Seg(0.9f, 320f, 150f), Seg(0.9f, 150f, 320f)
            )
            else -> listOf(150f, 170f, 190f, 215f, 240f, 285f).flatMap {
                listOf(Seg(0.4f, it, it), Seg(0.06f, 0f, 0f, 0f))
            }
        }
        val total = segs.sumOf { (it.dur * SR).toInt() }
        val out = ShortArray(min(total, MAX_SEC * SR))
        var phase = 0.0
        var pos = 0
        for (s in segs) {
            val n = (s.dur * SR).toInt()
            for (i in 0 until n) {
                if (pos >= out.size) break
                val t = i / n.toFloat()
                val f = s.f0 + (s.f1 - s.f0) * t
                phase += 2.0 * Math.PI * f / SR
                val fade = min(1f, min(i / 240f, (n - i) / 240f))
                var v = 0.0
                for (k in 1..6) v += sin(k * phase) / k
                out[pos++] = (v * s.amp * fade * 0.55 * 32767.0).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        return out
    }
}
