package com.tirusuara.kocak

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** ShortArray yang bisa bertambah. */
class ShortArrayList {
    private var data = ShortArray(1 shl 16)
    var size = 0
        private set

    fun add(src: ShortArray) {
        if (size + src.size > data.size) {
            data = data.copyOf(max(data.size * 2, size + src.size))
        }
        System.arraycopy(src, 0, data, size, src.size)
        size += src.size
    }

    fun toArray(): ShortArray = data.copyOf(size)
}

/** Rekam mikrofon 16 kHz mono, sambil menghitung pitch live untuk digambar. */
class Recorder {
    @Volatile
    private var stopFlag = false

    fun stop() {
        stopFlag = true
    }

    @SuppressLint("MissingPermission")
    suspend fun record(maxSamples: Int, onLive: (FloatArray) -> Unit): ShortArray =
        withContext(Dispatchers.IO) {
            stopFlag = false
            val minBuf = AudioRecord.getMinBufferSize(
                SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf <= 0) throw IllegalStateException("Mikrofon tidak didukung")
            val rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, SR,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, SR)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                throw IllegalStateException("Mikrofon gagal dibuka (izin ditolak / dipakai app lain)")
            }
            val buf = ShortArray(maxSamples + HOP)
            val chunk = ShortArray(HOP)
            val live = ArrayList<Float>()
            var count = 0
            var frames = 0
            try {
                rec.startRecording()
                while (!stopFlag && count < maxSamples && currentCoroutineContext().isActive) {
                    val n = rec.read(chunk, 0, HOP)
                    if (n <= 0) break
                    val take = min(n, buf.size - count)
                    System.arraycopy(chunk, 0, buf, count, take)
                    count += take
                    var changed = false
                    while (frames * HOP + FRAME <= count) {
                        val hz = Dsp.pitchHz(buf, frames * HOP)
                        live.add(if (hz > 0f) Dsp.hzToSemitone(hz) else Float.NaN)
                        frames++
                        changed = true
                    }
                    if (changed) onLive(live.toFloatArray())
                }
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
            }
            buf.copyOf(min(count, maxSamples))
        }
}

/** Pemutar PCM 16 kHz mono. play() baru otomatis menghentikan yang lama. */
class Player {
    @Volatile
    private var gen = 0

    fun stop() {
        gen++
    }

    suspend fun play(pcm: ShortArray): Unit = withContext(Dispatchers.IO) {
        if (pcm.isEmpty()) return@withContext
        gen++
        val my = gen
        val minBuf = AudioTrack.getMinBufferSize(
            SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        try {
            track.play()
            var off = 0
            while (off < pcm.size && gen == my && isActive) {
                val n = min(2048, pcm.size - off)
                val w = track.write(pcm, off, n)
                if (w <= 0) break
                off += w
            }
            var waited = 0
            while (gen == my && isActive && track.playbackHeadPosition < pcm.size && waited < 20000) {
                delay(30)
                waited += 30
            }
        } finally {
            try {
                track.pause()
                track.flush()
                track.stop()
            } catch (_: Exception) {}
            track.release()
        }
    }
}

/** Decode file audio (mp3/ogg/wav/aac/m4a...) jadi PCM 16 kHz mono. */
object AudioDecoder {
    fun decodeFile(path: String, maxSeconds: Int): ShortArray {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(path)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    idx = i
                    fmt = f
                    break
                }
            }
            if (idx < 0 || fmt == null) throw IllegalStateException("File tidak berisi audio")
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val limit = (maxSeconds + 1) * sr * ch

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val out = ShortArrayList()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            try {
                while (!outputDone) {
                    if (!inputDone) {
                        val ii = codec.dequeueInputBuffer(10000)
                        if (ii >= 0) {
                            val ib = codec.getInputBuffer(ii)!!
                            val sz = ex.readSampleData(ib, 0)
                            if (sz < 0) {
                                codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }
                    val oi = codec.dequeueOutputBuffer(info, 10000)
                    if (oi >= 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val tmp = ShortArray(sb.remaining())
                        sb.get(tmp)
                        out.add(tmp)
                        codec.releaseOutputBuffer(oi, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        if (out.size > limit) outputDone = true
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val nf = codec.outputFormat
                        sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            } finally {
                try { codec.stop() } catch (_: Exception) {}
                codec.release()
            }
            return toMono16k(out.toArray(), sr, max(1, ch), maxSeconds)
        } finally {
            ex.release()
        }
    }

    private fun toMono16k(src: ShortArray, sr: Int, ch: Int, maxSeconds: Int): ShortArray {
        val monoLen = src.size / ch
        val mono = FloatArray(monoLen)
        for (i in 0 until monoLen) {
            var s = 0
            for (c in 0 until ch) s += src[i * ch + c]
            mono[i] = s / ch.toFloat()
        }
        val outLen = min((monoLen.toLong() * SR / sr).toInt(), maxSeconds * SR)
        val out = ShortArray(outLen)
        val ratio = sr.toDouble() / SR
        for (i in 0 until outLen) {
            val pos = i * ratio
            val i0 = pos.toInt()
            val i1 = min(i0 + 1, monoLen - 1)
            val frac = (pos - i0).toFloat()
            val v = mono[i0] * (1f - frac) + mono[i1] * frac
            out[i] = v.toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }
}
