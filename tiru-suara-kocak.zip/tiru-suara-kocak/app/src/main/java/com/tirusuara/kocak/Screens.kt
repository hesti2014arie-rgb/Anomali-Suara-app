package com.tirusuara.kocak

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.max

private val Yellow = Color(0xFFFFD43B)
private val Pink = Color(0xFFFF6B9D)
private val Cyan = Color(0xFF4DD4E8)
private val Bg = Color(0xFF14102B)
private val CardBg = Color(0xFF211B45)

@Composable
fun TiruTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Yellow, onPrimary = Color.Black,
            secondary = Pink, tertiary = Cyan,
            background = Bg, surface = CardBg, onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun AppRoot(vm: GameViewModel) {
    val s by vm.ui.collectAsState()
    BackHandler(enabled = s.screen != Screen.HOME) { vm.leave() }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            s.error?.let { err ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF5A1E2E))) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⚠️ $err", Modifier.weight(1f))
                        TextButton(onClick = { vm.dismissError() }) { Text("OK") }
                    }
                }
            }
            when (s.screen) {
                Screen.HOME -> HomeScreen(s, vm)
                Screen.LOBBY -> LobbyScreen(s, vm)
                Screen.ROUND -> RoundScreen(s, vm)
                Screen.REVEAL -> RevealScreen(s, vm)
                Screen.FINAL -> FinalScreen(s, vm)
            }
        }
    }
}

@Composable
fun HomeScreen(s: UiState, vm: GameViewModel) {
    var code by remember { mutableStateOf("") }
    var showServer by remember { mutableStateOf(s.serverUrl.isBlank()) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("🎤 Tiru Suara Kocak", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Yellow)
        Text("Tiru suara karakter sepersis mungkin. Juri yang menilai, teman-temanmu yang menertawakan! 😆")
        OutlinedTextField(
            value = s.name, onValueChange = { vm.setName(it) },
            label = { Text("Nama kamu") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { vm.createRoom() }, enabled = !s.busy,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("➕ Buat Room", fontSize = 18.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = code, onValueChange = { code = it.uppercase().take(4) },
                label = { Text("Kode room") }, singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = { vm.joinRoom(code) }, enabled = !s.busy && code.length == 4,
                colors = ButtonDefaults.buttonColors(containerColor = Pink),
                modifier = Modifier.height(56.dp)
            ) { Text("Gabung") }
        }
        OutlinedButton(
            onClick = { vm.startSolo() }, enabled = !s.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("🎯 Latihan Solo (tanpa server)") }
        if (s.busy) LinearProgressIndicator(Modifier.fillMaxWidth())

        TextButton(onClick = { showServer = !showServer }) { Text("⚙️ Server multiplayer") }
        if (showServer) {
            OutlinedTextField(
                value = s.serverUrl, onValueChange = { vm.setServerUrl(it) },
                label = { Text("URL Firebase Realtime Database") },
                placeholder = { Text("https://xxx-default-rtdb.firebasedatabase.app") },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Semua pemain harus pakai URL yang sama. Cara bikinnya ada di README.",
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
fun LobbyScreen(s: UiState, vm: GameViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (s.solo) "Latihan Solo" else "Kode Room", fontSize = 16.sp)
        if (!s.solo) {
            Text(
                s.code, fontSize = 64.sp, fontWeight = FontWeight.ExtraBold, color = Yellow,
                letterSpacing = 8.sp
            )
            Text("Bagikan kode ini ke teman (maks 4 pemain)", fontSize = 13.sp)
        }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBg)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pemain (${s.players.size}/4)", fontWeight = FontWeight.Bold)
                for (i in 0 until 4) {
                    val p = s.players.getOrNull(i)
                    Text(
                        if (p != null) "${if (p.id == s.myId) "👉" else "🙂"} ${p.name}" else "⏳ menunggu pemain…",
                        color = if (p != null) Color.White else Color.White.copy(alpha = 0.4f)
                    )
                }
            }
        }
        if (s.isHost) {
            Button(
                onClick = { vm.startGame() }, enabled = !s.busy && s.players.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("▶ Mulai Game (3 ronde)", fontSize = 18.sp) }
        } else {
            Text("Menunggu host memulai game… ⏳")
        }
        OutlinedButton(onClick = { vm.leave() }) { Text("Keluar") }
    }
}

@Composable
fun RoundScreen(s: UiState, vm: GameViewModel) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startRecording() else vm.showError("Izin mikrofon dibutuhkan untuk main")
    }
    fun onRecord() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.startRecording() else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ronde ${s.round + 1}/3", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Yellow)
            Spacer(Modifier.weight(1f))
            if (!s.solo) Text("Room ${s.code}", fontSize = 14.sp)
        }

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBg)) {
            Column(
                Modifier.padding(12.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(12.dp)).background(Bg),
                    contentAlignment = Alignment.Center
                ) {
                    val img = s.image
                    if (img != null) {
                        Image(
                            bitmap = img, contentDescription = s.clip?.character,
                            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                        )
                    } else if (s.loadingClip) {
                        CircularProgressIndicator()
                    } else {
                        Text(s.clip?.emoji ?: "🎭", fontSize = 72.sp)
                    }
                }
                Text(s.clip?.character ?: "Memuat…", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(s.clip?.title ?: "", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
                OutlinedButton(
                    onClick = { vm.playRef() },
                    enabled = !s.recording && s.countdown == 0 && !s.loadingClip && !s.scoring
                ) { Text(if (s.refPlaying) "🔊 Memutar…" else "🔊 Dengar suara asli") }
            }
        }

        ContourBox(s.refSt, s.liveSt, s.refSec + 1.2f)
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("━ Suara asli", color = Pink, fontSize = 12.sp)
            Text("━ Suaramu", color = Cyan, fontSize = 12.sp)
            Text("(garis digeser ke nada yang sama)", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
        }

        if (s.countdown > 0) {
            Text(
                "${s.countdown}", fontSize = 72.sp, fontWeight = FontWeight.ExtraBold, color = Yellow,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }

        when {
            s.myDone -> ResultCard(s.myResult)
            s.scoring -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator(Modifier.height(24.dp))
                Text("Juri lagi mikir & kirim suaramu… 🤔")
            }
            s.recording -> Button(
                onClick = { vm.stopRecording() },
                colors = ButtonDefaults.buttonColors(containerColor = Pink),
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("⏹ Selesai", fontSize = 18.sp) }
            else -> Button(
                onClick = { onRecord() }, enabled = !s.loadingClip && s.countdown == 0,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("🎙️ Rekam!", fontSize = 18.sp) }
        }

        Text("Status pemain", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            for (p in s.players) {
                val done = p.scores.getOrElse(s.round) { -1 } >= 0
                Text("${if (done) "✅" else "⏳"} ${p.name}", fontSize = 13.sp)
            }
        }
        if (s.isHost && s.myDone && s.players.any { it.scores.getOrElse(s.round) { -1 } < 0 }) {
            TextButton(onClick = { vm.forceReveal() }) { Text("Lanjut tanpa menunggu pemain lain") }
        }
        if (s.myDone && !s.isHost) Text("Menunggu pemain lain… ⏳", fontSize = 13.sp)
    }
}

@Composable
fun ResultCard(r: ScoreResult?) {
    if (r == null) return
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBg)) {
        Column(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("${r.total}", fontSize = 56.sp, fontWeight = FontWeight.ExtraBold, color = Yellow)
            Text("poin", fontSize = 13.sp)
            Text(r.note, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(
                "Nada ${r.pitch} • Tekanan suara ${r.energy} • Timing ${r.rhythm}",
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f)
            )
        }
    }
}

/** Kotak besar: garis pitch suara asli (pink) vs suara pemain (biru). */
@Composable
fun ContourBox(ref: FloatArray, live: FloatArray, totalSec: Float) {
    val liveC = Scorer.center(live)
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0E0B20))
            .border(2.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
    ) {
        val w = size.width
        val h = size.height
        val range = 10f
        for (i in 1..3) {
            val y = h * i / 4f
            drawLine(Color.White.copy(alpha = 0.08f), Offset(0f, y), Offset(w, y), 2f)
        }
        fun yOf(st: Float): Float = h / 2f - (st.coerceIn(-range, range) / range) * (h / 2f - 12f)
        fun xOf(frame: Int): Float =
            ((frame * HOP + FRAME / 2) / SR.toFloat()) / max(totalSec, 0.1f) * w

        fun drawLineSeries(data: FloatArray, color: Color, width: Float) {
            var prev: Offset? = null
            for (i in data.indices) {
                val v = data[i]
                if (v.isNaN()) {
                    prev = null
                    continue
                }
                val p = Offset(xOf(i), yOf(v))
                val pv = prev
                if (pv != null) drawLine(color, pv, p, width, StrokeCap.Round)
                else drawCircle(color, width / 2f, p)
                prev = p
            }
        }
        drawLineSeries(ref, Pink.copy(alpha = 0.9f), 16f)
        drawLineSeries(liveC, Cyan, 9f)
    }
}

@Composable
fun RevealScreen(s: UiState, vm: GameViewModel) {
    val sorted = s.players.sortedByDescending { max(0, it.scores.getOrElse(s.round) { -1 }) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Hasil Ronde ${s.round + 1}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Yellow)
        Text("🎬 ${s.clip?.character ?: ""}", fontSize = 14.sp)

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBg)) {
            Box(Modifier.padding(16.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val label = s.playingLabel
                when {
                    s.revealStatus.isNotEmpty() -> Text(s.revealStatus)
                    label != null -> Text("🔊 $label", fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    else -> Text("Selesai diputar")
                }
            }
        }

        sorted.forEachIndexed { i, p ->
            val sc = max(0, p.scores.getOrElse(s.round) { -1 })
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBg)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(listOf("🥇", "🥈", "🥉", "4️⃣")[i.coerceAtMost(3)], fontSize = 22.sp)
                    Spacer(Modifier.padding(4.dp))
                    Text(p.name + if (p.id == s.myId) " (kamu)" else "", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("$sc", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Yellow)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.replay() }, enabled = s.revealStatus.isEmpty()) { Text("🔁 Putar ulang") }
            if (s.playingLabel != null) OutlinedButton(onClick = { vm.stopPlayback() }) { Text("⏹ Stop") }
        }

        if (s.isHost) {
            Button(
                onClick = { vm.nextRound() }, enabled = !s.busy,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text(if (s.round < 2) "Ronde berikutnya ▶" else "Lihat hasil akhir 🏆", fontSize = 18.sp) }
        } else {
            Text("Menunggu host lanjut… ⏳")
        }
    }
}

@Composable
fun FinalScreen(s: UiState, vm: GameViewModel) {
    val sorted = s.players.sortedByDescending { it.total }
    val best = sorted.firstOrNull()?.total ?: 0
    val winners = sorted.filter { it.total == best }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🏆", fontSize = 64.sp)
        Text(
            if (winners.size == 1) "${winners[0].name} menang!" else "Seri! ${winners.joinToString(" & ") { it.name }}",
            fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Yellow, textAlign = TextAlign.Center
        )
        sorted.forEachIndexed { i, p ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBg)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(listOf("🥇", "🥈", "🥉", "4️⃣")[i.coerceAtMost(3)], fontSize = 22.sp)
                        Spacer(Modifier.padding(4.dp))
                        Text(p.name + if (p.id == s.myId) " (kamu)" else "", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text("${p.total}", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Yellow)
                    }
                    Text(
                        "R1 ${max(0, p.scores[0])} • R2 ${max(0, p.scores[1])} • R3 ${max(0, p.scores[2])}",
                        fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
        }
        if (s.isHost) {
            Button(
                onClick = { vm.playAgain() }, enabled = !s.busy,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("🔄 Main lagi", fontSize = 18.sp) }
        } else {
            Text("Host bisa mulai ronde baru, atau kamu bisa keluar.", fontSize = 13.sp)
        }
        OutlinedButton(onClick = { vm.leave() }) { Text("Keluar") }
    }
}
