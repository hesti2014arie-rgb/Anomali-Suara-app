package com.tirusuara.kocak

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap

object Http {
    fun request(method: String, url: String, body: String? = null): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 8000
            c.readTimeout = 20000
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }
            if (code !in 200..299) throw IOException("HTTP $code ${text?.take(120) ?: ""}")
            return text
        } finally {
            c.disconnect()
        }
    }

    /** Download dengan ikut redirect (termasuk http -> https). */
    fun download(url: String, maxBytes: Int = 15_000_000): ByteArray {
        var current = url
        repeat(6) {
            val c = URL(current).openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 10000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", "TiruSuaraKocak/1.0")
                val code = c.responseCode
                if (code in listOf(301, 302, 303, 307, 308)) {
                    val loc = c.getHeaderField("Location") ?: throw IOException("Redirect tanpa Location")
                    current = URL(URL(current), loc).toString()
                    return@repeat
                }
                if (code !in 200..299) throw IOException("HTTP $code saat download")
                val bytes = c.inputStream.use { it.readBytes() }
                if (bytes.size > maxBytes) throw IOException("File terlalu besar")
                return bytes
            } finally {
                c.disconnect()
            }
        }
        throw IOException("Terlalu banyak redirect")
    }
}

object PcmCodec {
    fun encode(pcm: ShortArray): String {
        val bb = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (s in pcm) bb.putShort(s)
        return Base64.encodeToString(bb.array(), Base64.NO_WRAP)
    }

    fun decode(b64: String): ShortArray {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val sb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val out = ShortArray(sb.remaining())
        sb.get(out)
        return out
    }
}

/**
 * Penyimpanan room. Struktur data:
 *   rooms/{code}/meta                 -> JSON (host, state, round, clips)
 *   rooms/{code}/players/{pid}        -> JSON (name, joined, s0, s1, s2)
 *   rooms/{code}/audio/a{round}_{pid} -> string base64 PCM
 */
interface RoomApi {
    suspend fun getMeta(code: String): JSONObject?
    suspend fun putMeta(code: String, meta: JSONObject)
    suspend fun getPlayers(code: String): JSONObject
    suspend fun putPlayer(code: String, pid: String, data: JSONObject)
    suspend fun putScore(code: String, pid: String, round: Int, score: Int)
    suspend fun deletePlayer(code: String, pid: String)
    suspend fun putAudio(code: String, round: Int, pid: String, b64: String)
    suspend fun getAudio(code: String, round: Int, pid: String): String?
    suspend fun deleteRoom(code: String)
}

/** Firebase Realtime Database lewat REST (tanpa SDK, tanpa google-services.json). */
class FirebaseApi(base: String) : RoomApi {
    private val b = base.trim().trimEnd('/')

    private fun url(path: String) = "$b/rooms/$path.json"

    private suspend fun get(path: String): Any? = withContext(Dispatchers.IO) {
        val t = Http.request("GET", url(path))
        if (t.isNullOrBlank()) null
        else JSONTokener(t).nextValue().takeIf { it != JSONObject.NULL }
    }

    private suspend fun put(path: String, json: String) = withContext(Dispatchers.IO) {
        Http.request("PUT", url(path), json)
        Unit
    }

    private suspend fun delete(path: String) = withContext(Dispatchers.IO) {
        Http.request("DELETE", url(path))
        Unit
    }

    override suspend fun getMeta(code: String) = get("$code/meta") as? JSONObject
    override suspend fun putMeta(code: String, meta: JSONObject) = put("$code/meta", meta.toString())
    override suspend fun getPlayers(code: String) =
        (get("$code/players") as? JSONObject) ?: JSONObject()

    override suspend fun putPlayer(code: String, pid: String, data: JSONObject) =
        put("$code/players/$pid", data.toString())

    override suspend fun putScore(code: String, pid: String, round: Int, score: Int) =
        put("$code/players/$pid/s$round", score.toString())

    override suspend fun deletePlayer(code: String, pid: String) = delete("$code/players/$pid")
    override suspend fun putAudio(code: String, round: Int, pid: String, b64: String) =
        put("$code/audio/a${round}_$pid", JSONObject.quote(b64))

    override suspend fun getAudio(code: String, round: Int, pid: String) =
        get("$code/audio/a${round}_$pid") as? String

    override suspend fun deleteRoom(code: String) = delete(code)
}

/** Penyimpanan di memori untuk mode Latihan Solo (tanpa internet). */
class MemoryApi : RoomApi {
    private val metas = ConcurrentHashMap<String, String>()
    private val players = ConcurrentHashMap<String, ConcurrentHashMap<String, String>>()
    private val audio = ConcurrentHashMap<String, String>()

    private fun pl(code: String) = players.getOrPut(code) { ConcurrentHashMap() }

    override suspend fun getMeta(code: String) = metas[code]?.let { JSONObject(it) }
    override suspend fun putMeta(code: String, meta: JSONObject) {
        metas[code] = meta.toString()
    }

    override suspend fun getPlayers(code: String): JSONObject {
        val o = JSONObject()
        for ((k, v) in pl(code)) o.put(k, JSONObject(v))
        return o
    }

    override suspend fun putPlayer(code: String, pid: String, data: JSONObject) {
        pl(code)[pid] = data.toString()
    }

    override suspend fun putScore(code: String, pid: String, round: Int, score: Int) {
        val cur = pl(code)[pid]?.let { JSONObject(it) } ?: return
        cur.put("s$round", score)
        pl(code)[pid] = cur.toString()
    }

    override suspend fun deletePlayer(code: String, pid: String) {
        pl(code).remove(pid)
    }

    override suspend fun putAudio(code: String, round: Int, pid: String, b64: String) {
        audio["$code/a${round}_$pid"] = b64
    }

    override suspend fun getAudio(code: String, round: Int, pid: String) =
        audio["$code/a${round}_$pid"]

    override suspend fun deleteRoom(code: String) {
        metas.remove(code)
        players.remove(code)
    }
}
