package com.tirusuara.kocak

import android.app.Application
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

enum class Screen { HOME, LOBBY, ROUND, REVEAL, FINAL }

data class PlayerInfo(
    val id: String,
    val name: String,
    val scores: List<Int>,
    val joined: Long
) {
    val total: Int get() = scores.sumOf { max(0, it) }
}

data class UiState(
    val screen: Screen = Screen.HOME,
    val name: String = "",
    val serverUrl: String = "",
    val busy: Boolean = false,
    val error: String? = null,

    val code: String = "",
    val myId: String = "",
    val isHost: Boolean = false,
    val solo: Boolean = false,
    val players: List<PlayerInfo> = emptyList(),
    val round: Int = 0,
    val clipIds: List<String> = emptyList(),

    val clip: Clip? = null,
    val image: ImageBitmap? = null,
    val loadingClip: Boolean = false,
    val refSt: FloatArray = FloatArray(0),
    val refSec: Float = 0f,
    val liveSt: FloatArray = FloatArray(0),
    val countdown: Int = 0,
    val recording: Boolean = false,
    val scoring: Boolean = false,
    val myDone: Boolean = false,
    val myResult: ScoreResult? = null,
    val refPlaying: Boolean = false,

    val playingLabel: String? = null,
    val revealStatus: String = ""
)

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val appCtx: Context = app.applicationContext
    private val prefs = appCtx.getSharedPreferences("tiru", Context.MODE_PRIVATE)
    private val clips: List<Clip> = ClipRepo.load(appCtx)

    private val _ui = MutableStateFlow(
        UiState(
            name = prefs.getString("name", "") ?: "",
            serverUrl = prefs.getString("url", null) ?: BuildConfig.RTDB_URL
        )
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var api: RoomApi? = null
    private var pollJob: Job? = null
    private var recJob: Job? = null
    private var clipJob: Job? = null
    private var revealJob: Job? = null

    private val recorder = Recorder()
    private val player = Player()

    private var refPcm = ShortArray(0)
    private var refClipId = ""
    private val myPcm = HashMap<Int, ShortArray>()
    private var revealItems: List<Triple<String, Int, ShortArray?>> = emptyList()
    private var lastKey = ""
    private var hostRevealSent = ""

    // ---------- pengaturan ----------

    fun setName(n: String) {
        prefs.edit().putString("name", n).apply()
        _ui.update { it.copy(name = n) }
    }

    fun setServerUrl(u: String) {
        prefs.edit().putString("url", u).apply()
        _ui.update { it.copy(serverUrl = u) }
    }

    fun dismissError() = _ui.update { it.copy(error = null) }
    fun showError(msg: String) = _ui.update { it.copy(error = msg) }

    // ---------- room ----------

    private fun launchBusy(block: suspend () -> Unit) {
        viewModelScope.launch {
            _ui.update { it.copy(busy = true, error = null) }
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                _ui.update { it.copy(error = "Koneksi gagal: ${e.message}") }
            } catch (e: Exception) {
                _ui.update { it.copy(error = e.message ?: "Terjadi error") }
            } finally {
                _ui.update { it.copy(busy = false) }
            }
        }
    }

    private fun randomCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..4).map { chars.random() }.joinToString("")
    }

    private fun randomId(): String {
        val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        return "p" + (1..8).map { chars.random() }.joinToString("")
    }

    private fun cleanName(): String =
        _ui.value.name.trim().take(12).ifBlank { "Pemain" }

    private fun playerJson(name: String) = JSONObject()
        .put("name", name)
        .put("joined", System.currentTimeMillis())
        .put("s0", -1).put("s1", -1).put("s2", -1)

    private fun metaJson(host: String, state: String, round: Int, ids: List<String>) = JSONObject()
        .put("host", host)
        .put("state", state)
        .put("round", round)
        .put("clips", JSONArray(ids))
        .put("created", System.currentTimeMillis())

    private fun remoteApi(): RoomApi {
        val url = _ui.value.serverUrl.trim()
        if (!url.startsWith("http")) {
            throw IllegalStateException("Isi dulu alamat server di ⚙️ Server multiplayer")
        }
        return FirebaseApi(url)
    }

    fun createRoom() = launchBusy {
        val a = remoteApi()
        var code = ""
        repeat(8) {
            if (code.isEmpty()) {
                val c = randomCode()
                if (a.getMeta(c) == null) code = c
            }
        }
        if (code.isEmpty()) throw IllegalStateException("Gagal membuat kode, coba lagi")
        val pid = randomId()
        a.putMeta(code, metaJson(pid, "lobby", 0, emptyList()))
        a.putPlayer(code, pid, playerJson(cleanName()))
        enter(a, code, pid, host = true, solo = false)
    }

    fun joinRoom(codeIn: String) = launchBusy {
        val a = remoteApi()
        val code = codeIn.trim().uppercase()
        if (code.length != 4) throw IllegalStateException("Kode room itu 4 karakter")
        val meta = a.getMeta(code) ?: throw IllegalStateException("Kode $code tidak ditemukan")
        if (meta.optString("state") != "lobby") throw IllegalStateException("Permainan sudah dimulai")
        if (a.getPlayers(code).length() >= 4) throw IllegalStateException("Room penuh (maks 4 pemain)")
        val pid = randomId()
        a.putPlayer(code, pid, playerJson(cleanName()))
        enter(a, code, pid, host = false, solo = false)
    }

    fun startSolo() = launchBusy {
        val a = MemoryApi()
        val pid = randomId()
        a.putMeta("SOLO", metaJson(pid, "lobby", 0, emptyList()))
        a.putPlayer("SOLO", pid, playerJson(cleanName()))
        enter(a, "SOLO", pid, host = true, solo = true)
    }

    private fun enter(a: RoomApi, code: String, pid: String, host: Boolean, solo: Boolean) {
        api = a
        myPcm.clear()
        lastKey = ""
        hostRevealSent = ""
        _ui.update {
            it.copy(
                screen = Screen.LOBBY, code = code, myId = pid, isHost = host, solo = solo,
                players = emptyList(), round = 0, error = null
            )
        }
        pollJob?.cancel()
        pollJob = viewModelScope.launch { pollLoop(a, code, solo) }
    }

    private suspend fun pollLoop(a: RoomApi, code: String, solo: Boolean) {
        var fails = 0
        while (currentCoroutineContextActive()) {
            try {
                val meta = a.getMeta(code)
                if (meta == null) {
                    leaveLocal("Room ditutup oleh host")
                    return
                }
                val ps = a.getPlayers(code)
                onSnapshot(a, code, meta, ps)
                fails = 0
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fails++
                if (fails >= 5) _ui.update { it.copy(error = "Koneksi putus, mencoba lagi…") }
            }
            delay(if (solo) 300 else 1000)
        }
    }

    private suspend fun currentCoroutineContextActive(): Boolean =
        kotlinx.coroutines.currentCoroutineContext().isActive

    private suspend fun onSnapshot(a: RoomApi, code: String, meta: JSONObject, ps: JSONObject) {
        val list = ps.keys().asSequence().mapNotNull { id ->
            val o = ps.optJSONObject(id) ?: return@mapNotNull null
            PlayerInfo(
                id, o.optString("name", "?"),
                listOf(o.optInt("s0", -1), o.optInt("s1", -1), o.optInt("s2", -1)),
                o.optLong("joined")
            )
        }.sortedBy { it.joined }.toList()

        val state = meta.optString("state", "lobby")
        val round = meta.optInt("round", 0)
        val ids = meta.optJSONArray("clips")?.let { arr -> List(arr.length()) { arr.getString(it) } }
            ?: emptyList()

        _ui.update { it.copy(players = list, clipIds = ids) }

        val key = "$state:$round"
        if (key != lastKey) {
            lastKey = key
            transition(state, round, ids)
        }

        val s = _ui.value
        if (s.isHost && state == "record" && round in 0..2 && list.isNotEmpty() &&
            list.all { it.scores[round] >= 0 } && hostRevealSent != key
        ) {
            hostRevealSent = key
            a.putMeta(code, metaJson(s.myId, "reveal", round, ids))
        }
    }

    private fun transition(state: String, round: Int, ids: List<String>) {
        when (state) {
            "lobby" -> {
                stopAudioJobs()
                myPcm.clear()
                hostRevealSent = ""
                _ui.update { it.copy(screen = Screen.LOBBY, playingLabel = null) }
            }
            "record" -> beginRound(round, ids)
            "reveal" -> beginReveal(round, ids)
            "final" -> {
                stopAudioJobs()
                _ui.update { it.copy(screen = Screen.FINAL, playingLabel = null) }
            }
        }
    }

    private fun stopAudioJobs() {
        recJob?.cancel()
        recorder.stop()
        clipJob?.cancel()
        revealJob?.cancel()
        player.stop()
    }

    // ---------- ronde ----------

    private suspend fun loadRef(round: Int, ids: List<String>): Clip? {
        val id = ids.getOrNull(round) ?: return null
        val clip = clips.find { it.id == id }
            ?: throw IllegalStateException("Klip \"$id\" tidak ada di app ini. Samakan versi app semua pemain.")
        refPcm = ClipRepo.pcm(appCtx, clip)
        refClipId = id
        return clip
    }

    private fun beginRound(round: Int, ids: List<String>) {
        stopAudioJobs()
        _ui.update {
            it.copy(
                screen = Screen.ROUND, round = round, clip = null, image = null, loadingClip = true,
                refSt = FloatArray(0), liveSt = FloatArray(0), countdown = 0, recording = false,
                scoring = false, myDone = false, myResult = null, playingLabel = null, error = null
            )
        }
        clipJob = viewModelScope.launch {
            try {
                val clip = loadRef(round, ids) ?: return@launch
                val c = withContext(Dispatchers.Default) { Dsp.analyze(refPcm) }
                _ui.update {
                    it.copy(
                        clip = clip, loadingClip = false,
                        refSt = Scorer.center(c.pitch), refSec = refPcm.size / SR.toFloat()
                    )
                }
                val img = ClipRepo.image(clip)
                _ui.update { it.copy(image = img) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(loadingClip = false, error = "Gagal memuat klip: ${e.message}") }
            }
        }
    }

    fun playRef() {
        val s = _ui.value
        if (s.recording || s.countdown > 0 || refPcm.isEmpty()) return
        viewModelScope.launch {
            _ui.update { it.copy(refPlaying = true) }
            try {
                player.play(refPcm)
            } finally {
                _ui.update { it.copy(refPlaying = false) }
            }
        }
    }

    fun startRecording() {
        val s = _ui.value
        if (s.recording || s.myDone || s.scoring || s.loadingClip || s.countdown > 0 || refPcm.isEmpty()) return
        player.stop()
        val round = s.round
        recJob = viewModelScope.launch {
            try {
                for (i in 3 downTo 1) {
                    _ui.update { it.copy(countdown = i, error = null) }
                    delay(800)
                }
                _ui.update { it.copy(countdown = 0, recording = true, liveSt = FloatArray(0)) }
                val maxS = min(refPcm.size + (SR * 1.2f).toInt(), MAX_SEC * SR)
                val pcm = recorder.record(maxS) { st -> _ui.update { it.copy(liveSt = st) } }
                _ui.update { it.copy(recording = false, scoring = true) }
                finishRecording(round, pcm)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update {
                    it.copy(
                        recording = false, scoring = false, countdown = 0,
                        error = e.message ?: "Gagal merekam"
                    )
                }
            }
        }
    }

    fun stopRecording() = recorder.stop()

    private suspend fun finishRecording(round: Int, pcm: ShortArray) {
        val result = withContext(Dispatchers.Default) {
            Scorer.score(Dsp.analyze(refPcm), Dsp.analyze(pcm))
        }
        val a = api ?: return
        val s = _ui.value
        myPcm[round] = pcm
        a.putAudio(s.code, round, s.myId, PcmCodec.encode(pcm))
        a.putScore(s.code, s.myId, round, result.total)
        _ui.update { it.copy(scoring = false, myDone = true, myResult = result) }
    }

    fun forceReveal() {
        val s = _ui.value
        val a = api ?: return
        if (!s.isHost) return
        launchBusy {
            hostRevealSent = "record:${s.round}"
            a.putMeta(s.code, metaJson(s.myId, "reveal", s.round, s.clipIds))
        }
    }

    // ---------- reveal ----------

    private fun beginReveal(round: Int, ids: List<String>) {
        stopAudioJobs()
        _ui.update {
            it.copy(
                screen = Screen.REVEAL, round = round, playingLabel = null,
                revealStatus = "Mengambil rekaman semua pemain…"
            )
        }
        revealJob = viewModelScope.launch {
            try {
                val a = api ?: return@launch
                val s = _ui.value
                if (refClipId != ids.getOrNull(round)) loadRef(round, ids)
                val items = s.players.map { p ->
                    val pcm: ShortArray? = if (p.id == s.myId) {
                        myPcm[round]
                    } else {
                        try {
                            a.getAudio(s.code, round, p.id)?.let { PcmCodec.decode(it) }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            null
                        }
                    }
                    Triple(p.name, p.scores[round], pcm)
                }
                revealItems = items
                playSequence()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(revealStatus = "", error = "Gagal memutar: ${e.message}") }
            }
        }
    }

    /** Suara asli diulang dulu, lalu suara tiap pemain diputar bergantian. */
    private suspend fun playSequence() {
        _ui.update { it.copy(revealStatus = "") }
        _ui.update { it.copy(playingLabel = "🎬 Suara asli") }
        player.play(refPcm)
        delay(400)
        for ((name, score, pcm) in revealItems) {
            _ui.update { it.copy(playingLabel = "🎤 $name • ${max(0, score)} poin") }
            if (pcm != null) player.play(pcm)
            delay(400)
        }
        _ui.update { it.copy(playingLabel = null) }
    }

    fun replay() {
        revealJob?.cancel()
        player.stop()
        revealJob = viewModelScope.launch {
            try {
                playSequence()
            } catch (e: CancellationException) {
                throw e
            }
        }
    }

    fun stopPlayback() {
        revealJob?.cancel()
        player.stop()
        _ui.update { it.copy(playingLabel = null) }
    }

    // ---------- aksi host ----------

    fun startGame() {
        val s = _ui.value
        val a = api ?: return
        if (!s.isHost) return
        launchBusy {
            val all = clips.map { it.id }.shuffled()
            val ids = List(3) { all[it % all.size] }
            a.putMeta(s.code, metaJson(s.myId, "record", 0, ids))
        }
    }

    fun nextRound() {
        val s = _ui.value
        val a = api ?: return
        if (!s.isHost) return
        launchBusy {
            val m = if (s.round < 2) metaJson(s.myId, "record", s.round + 1, s.clipIds)
            else metaJson(s.myId, "final", s.round, s.clipIds)
            a.putMeta(s.code, m)
        }
    }

    fun playAgain() {
        val s = _ui.value
        val a = api ?: return
        if (!s.isHost) return
        launchBusy {
            for (p in s.players) for (r in 0..2) a.putScore(s.code, p.id, r, -1)
            a.putMeta(s.code, metaJson(s.myId, "lobby", 0, emptyList()))
        }
    }

    // ---------- keluar ----------

    fun leave() {
        val s = _ui.value
        val a = api
        resetToHome(null)
        if (a != null && !s.solo && s.code.isNotEmpty()) {
            viewModelScope.launch {
                try {
                    if (s.isHost) a.deleteRoom(s.code) else a.deletePlayer(s.code, s.myId)
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun leaveLocal(msg: String) = resetToHome(msg)

    private fun resetToHome(msg: String?) {
        pollJob?.cancel()
        stopAudioJobs()
        api = null
        myPcm.clear()
        refPcm = ShortArray(0)
        refClipId = ""
        lastKey = ""
        val s = _ui.value
        _ui.value = UiState(name = s.name, serverUrl = s.serverUrl, error = msg)
    }

    override fun onCleared() {
        pollJob?.cancel()
        stopAudioJobs()
        super.onCleared()
    }
}
