package com.tirusuara.kocak

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

const val SR = 16000       // sample rate semua audio di game ini
const val FRAME = 640      // 40 ms
const val HOP = 320        // 20 ms
const val MAX_SEC = 6      // panjang maksimum klip / rekaman

/** pitch dalam semitone (NaN = tidak bersuara), env = kekerasan suara 0..1 per frame */
class Contour(val pitch: FloatArray, val env: FloatArray) {
    val size: Int get() = pitch.size
}

data class ScoreResult(
    val total: Int,
    val pitch: Int,
    val energy: Int,
    val rhythm: Int,
    val note: String
)

object Dsp {
    private const val TAU_MIN = 32   // 500 Hz
    private const val TAU_MAX = 229  // ~70 Hz

    fun hzToSemitone(hz: Float): Float = (12.0 * ln(hz / 55.0) / ln(2.0)).toFloat()

    fun rmsDb(x: ShortArray, start: Int): Float {
        var e = 0.0
        for (j in 0 until FRAME) {
            val v = x[start + j].toDouble()
            e += v * v
        }
        val rms = sqrt(e / FRAME) / 32768.0
        return (20.0 * log10(rms + 1e-9)).toFloat()
    }

    /** Pitch tracker gaya YIN. Mengembalikan Hz, atau 0 kalau tidak bersuara. */
    fun pitchHz(x: ShortArray, start: Int): Float {
        if (rmsDb(x, start) < -42f) return 0f
        val w = FRAME - TAU_MAX
        val d = FloatArray(TAU_MAX + 1)
        for (tau in 1..TAU_MAX) {
            var s = 0f
            for (j in 0 until w) {
                val diff = (x[start + j] - x[start + j + tau]).toFloat()
                s += diff * diff
            }
            d[tau] = s
        }
        val cm = FloatArray(TAU_MAX + 1)
        cm[0] = 1f
        var run = 0f
        for (tau in 1..TAU_MAX) {
            run += d[tau]
            cm[tau] = if (run == 0f) 1f else d[tau] * tau / run
        }
        var best = -1
        var tau = TAU_MIN
        while (tau <= TAU_MAX) {
            if (cm[tau] < 0.18f) {
                while (tau + 1 <= TAU_MAX && cm[tau + 1] < cm[tau]) tau++
                best = tau
                break
            }
            tau++
        }
        if (best < 0) return 0f
        val refined = if (best > 1 && best < TAU_MAX) {
            val a = cm[best - 1]
            val b = cm[best]
            val c = cm[best + 1]
            val den = a - 2f * b + c
            if (abs(den) > 1e-9f) best + 0.5f * (a - c) / den else best.toFloat()
        } else best.toFloat()
        return SR / refined
    }

    fun analyze(pcm: ShortArray): Contour {
        val n = if (pcm.size < FRAME) 0 else (pcm.size - FRAME) / HOP + 1
        val raw = FloatArray(n)
        val db = FloatArray(n)
        for (i in 0 until n) {
            val start = i * HOP
            val hz = pitchHz(pcm, start)
            raw[i] = if (hz > 0f) hzToSemitone(hz) else Float.NaN
            db[i] = rmsDb(pcm, start)
        }
        // buang frame bersuara yang sendirian (biasanya noise)
        val pitch = raw.copyOf()
        for (i in 0 until n) {
            if (!raw[i].isNaN()) {
                val l = i > 0 && !raw[i - 1].isNaN()
                val r = i < n - 1 && !raw[i + 1].isNaN()
                if (!l && !r) pitch[i] = Float.NaN
            }
        }
        val env = FloatArray(n) { ((db[it] + 60f) / 60f).coerceIn(0f, 1f) }
        val mx = env.maxOrNull() ?: 0f
        if (mx > 0f) for (i in 0 until n) env[i] = env[i] / mx
        return Contour(pitch, env)
    }
}

/** Penilai suara: bandingkan kontur pitch + kekerasan + timing pakai DTW. */
object Scorer {

    fun center(p: FloatArray): FloatArray {
        val v = p.filter { !it.isNaN() }.sorted()
        if (v.isEmpty()) return p.copyOf()
        val med = v[v.size / 2]
        return FloatArray(p.size) { if (p[it].isNaN()) Float.NaN else p[it] - med }
    }

    private fun trim(c: Contour): Contour {
        if (c.size == 0) return c
        var a = 0
        var b = c.size - 1
        while (a < b && c.env[a] < 0.25f) a++
        while (b > a && c.env[b] < 0.25f) b--
        return Contour(c.pitch.copyOfRange(a, b + 1), c.env.copyOfRange(a, b + 1))
    }

    private fun pitchCost(a: Float, b: Float): Float {
        val an = a.isNaN()
        val bn = b.isNaN()
        return when {
            an && bn -> 0f
            an || bn -> 0.8f
            else -> min(abs(a - b), 6f) / 6f
        }
    }

    fun score(refIn: Contour, usrIn: Contour): ScoreResult {
        val ref = trim(refIn)
        val usr = trim(usrIn)
        val usrVoiced = usr.pitch.count { !it.isNaN() }
        if (usr.size < 8 || usrVoiced < 12) {
            return ScoreResult(0, 0, 0, 0, "Suaranya nggak kedengeran 😶")
        }
        if (ref.size < 4) return ScoreResult(0, 0, 0, 0, "Klip asli terlalu pendek")

        val rp = center(ref.pitch)
        val up = center(usr.pitch)
        val n = ref.size
        val m = usr.size
        val band = (0.35f * max(n, m)).toInt() + abs(n - m) + 5
        val inf = 1e9f
        val w = m + 1
        val dm = FloatArray((n + 1) * w) { inf }
        dm[0] = 0f

        fun pC(i: Int, j: Int) = pitchCost(rp[i], up[j])
        fun eC(i: Int, j: Int) = abs(ref.env[i] - usr.env[j])

        for (i in 1..n) {
            val center = i * m.toFloat() / n
            val jLo = max(1, (center - band).toInt())
            val jHi = min(m, (center + band).toInt())
            for (j in jLo..jHi) {
                val c = 0.65f * pC(i - 1, j - 1) + 0.35f * eC(i - 1, j - 1)
                val best = min(dm[(i - 1) * w + (j - 1)], min(dm[(i - 1) * w + j], dm[i * w + (j - 1)]))
                dm[i * w + j] = c + best
            }
        }

        var i = n
        var j = m
        var sumP = 0f
        var sumE = 0f
        var steps = 0
        while (i > 0 && j > 0) {
            sumP += pC(i - 1, j - 1)
            sumE += eC(i - 1, j - 1)
            steps++
            val diag = dm[(i - 1) * w + (j - 1)]
            val up1 = dm[(i - 1) * w + j]
            val left = dm[i * w + (j - 1)]
            when {
                diag <= up1 && diag <= left -> { i--; j-- }
                up1 <= left -> i--
                else -> j--
            }
        }
        if (steps == 0) return ScoreResult(0, 0, 0, 0, "Gagal menilai")

        val avgP = sumP / steps
        val avgE = sumE / steps
        val ratio = min(n, m).toFloat() / max(n, m)

        val pitchScore = 100f * exp(-2f * avgP)
        val energyScore = 100f * exp(-2.5f * avgE)
        val rhythmScore = 100f * ((ratio - 0.5f) / 0.5f).coerceIn(0f, 1f)
        val total = (0.55f * pitchScore + 0.25f * energyScore + 0.20f * rhythmScore)
            .toInt().coerceIn(0, 100)

        val note = when {
            total >= 90 -> "Kembaran suaranya! 🤯"
            total >= 75 -> "Mantap, hampir sama! 🔥"
            total >= 55 -> "Lumayan lah 😎"
            total >= 35 -> "Hmm… mirip dikit 😅"
            else -> "Itu suara apa tadi? 🐸"
        }
        return ScoreResult(total, pitchScore.toInt(), energyScore.toInt(), rhythmScore.toInt(), note)
    }
}
