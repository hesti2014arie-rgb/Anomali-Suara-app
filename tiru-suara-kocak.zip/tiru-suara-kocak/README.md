# 🎤 Tiru Suara Kocak

Game komedi Android (Kotlin + Jetpack Compose): tiru suara karakter, dinilai juri suara, 2-4 pemain, 3 ronde.

## Cara main
1. Satu orang **Buat Room** -> muncul kode 4 karakter. Teman-teman masukkan kode itu lalu **Gabung**.
2. Host tekan **Mulai Game**. Tiap ronde ada 1 karakter + suaranya.
3. Dengar suara asli, tekan **Rekam**, ikuti garis pitch di kotak besar (pink = asli, biru = kamu).
4. Setelah semua selesai: suara asli diputar ulang, lalu suara tiap pemain diputar bergantian, dengan skor masing-masing.
5. Setelah 3 ronde, skor dijumlah, yang tertinggi menang.

Mau coba sendirian dulu? Pakai **Latihan Solo** (tanpa server).

## Build lewat GitHub
1. Upload semua isi folder ini ke repo (termasuk `.github`).
2. Tab **Actions** -> **Build Android APK** jalan otomatis, APK ada di **Artifacts**.
3. Push tag `v1.0` untuk otomatis membuat Release berisi APK.

## Setup server multiplayer (gratis, ~3 menit)
Game memakai **Firebase Realtime Database** lewat REST (tanpa SDK, tanpa `google-services.json`).

1. Buka console.firebase.google.com -> buat project.
2. **Build -> Realtime Database -> Create database**. Pilih lokasi, mode **test**.
3. Tab **Rules**, isi:
   ```json
   { "rules": { "rooms": { ".read": true, ".write": true } } }
   ```
4. Salin URL database, contoh `https://nama-project-default-rtdb.asia-southeast1.firebasedatabase.app`.
5. Pakai URL itu dengan salah satu cara:
   - Ketik di app: **⚙️ Server multiplayer** (tiap pemain sekali saja), atau
   - Isi `rtdbUrl=` di `gradle.properties`, atau
   - Di GitHub: **Settings -> Secrets and variables -> Actions -> Variables -> New variable** nama `RTDB_URL`. APK hasil build sudah terisi otomatis.

> Aturan di atas terbuka untuk siapa pun yang tahu URL-nya. Cukup untuk main bareng teman. Kalau mau serius, tambahkan Firebase Auth dan batasi aturannya.
> Rekaman suara disimpan sementara di room dan dihapus saat host keluar.

## Menambah karakter / suara dari internet
Bawaan app ada 4 suara demo buatan sendiri (aman hak cipta). Untuk menambah suara dan foto karakter, edit `app/src/main/assets/clips.json`:

```json
[
  {
    "id": "karakter1",
    "title": "Judul adegan",
    "character": "Nama karakter",
    "emoji": "🎭",
    "image": "https://contoh.com/foto.jpg",
    "audio": "https://contoh.com/suara.mp3"
  }
]
```
- `audio` boleh URL langsung ke file (mp3/ogg/wav/m4a) atau nama file yang ditaruh di `app/src/main/assets/clips/`.
- Maksimal 6 detik per klip (bagian lebih panjang dipotong).
- `id` harus unik. **Semua pemain harus pakai versi app yang sama** (daftar klip ikut ter-build di APK).
- Pakai hanya audio dan gambar yang kamu punya haknya. Untuk main pribadi bareng teman biasanya aman, tapi kalau mau dirilis ke Play Store, pakai aset berlisensi bebas.

## Cara juri menilai
Bukan model AI/neural network. Penilaian dihitung di HP lewat pemrosesan sinyal:
- **Nada (55%)**: pitch tiap 20 ms dilacak (algoritma YIN), lalu dibandingkan dengan *Dynamic Time Warping*. Nadanya dibandingkan secara relatif, jadi suara cowok bisa tetap cocok dengan suara cewek kalau pola naik-turunnya sama.
- **Tekanan suara (25%)**: pola keras-pelan.
- **Timing (20%)**: kemiripan durasi.

Bobot dan ambang ada di `Dsp.kt` (objek `Scorer`) kalau mau diubah.

## Catatan
- Pakai headset saat merekam supaya suara asli dari speaker tidak ikut terekam.
- minSdk 26 (Android 8.0+). Butuh izin mikrofon dan internet.
- Semua pemain memutar rekaman di HP masing-masing, jadi kalau main di satu ruangan, suaranya bisa tumpang tindih. Tekan **Stop** di HP yang tidak perlu.

## Struktur kode
- `Dsp.kt` - pitch tracker, penilai (DTW)
- `Audio.kt` - rekam, putar, decode mp3/ogg
- `Clips.kt` - daftar karakter + suara demo
- `Net.kt` - room multiplayer (Firebase REST + mode memori untuk solo)
- `GameViewModel.kt` - alur game (lobby, ronde, reveal, final)
- `Screens.kt` - UI Compose
